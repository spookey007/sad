import React from 'react';
import MemeCoinPage from './MemeCoinPage';

function App() {
  return (
    <div>
      <MemeCoinPage />
    </div>
  );
}

export default App;
